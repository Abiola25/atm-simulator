const readline = require('readline');
const r1 = readline.createInterface ({
    input:process.stdin,
    output:process.stdout
});
let balance = 10000;
let history = [];
let userID = '';
const correctPIN = '1234';
    r1.question("🆔 Enter your userID: ", function(enteredID) {
        userID = enteredID;
        checkPIN();
    });
    function checkPIN() {
    r1.question("🔐Enter your 4 digits PIN:" , function(enteredPIN) {
        if (enteredPIN === correctPIN) {
            console.log("Access granted");
            showMenu ();
        } else {
            console.log("Incorrect PIN. Try again.");
            checkPIN();
        }
    });
}
function showMenu() {
    console.log("\n===ATM Menu===");
    console.log("1. Check Balance");
    console.log("2. Deposit");
    console.log("3. Withdraw");
    console.log("4. View Transaction history");
    console.log("5. Exit");

    r1.question("\n Choose an option (1-5): " , function(choice) {
        switch (choice) {
            case '1':
                console.log(`\n 💰 Your balance is N${balance}`);
                showMenu ();
                break;

                case '2':
                    r1.question ("Enter deposit amount:", function(amount) {
                        const amt = parseFloat(amount);
                        balance += amt;
                        history.push(`{${userID}] Deposited N${amt}`);
                        console.log(`✅ N${amt} deposited successfully`);
                        showMenu ();
                    });
                    break;

                    case '3':
                        r1.question("Enter withdrawal amount:", function(amount) {
                            const amt = parseFloat(amount);
                                if (amt <= balance) {
                                    balance -= amt;
                                history.push(`[${userID}] withdrew N${amt}`);
                                console.log(`✅ N${amt} withdrawn successfully.`);
                            } else {
                                console.log("❌ Insufficient balance.");
                            }
                            showMenu();
                        });
                        break;

                        case '4':
                            console.log("\n Transaction History:");
                            if(history.length === 0) {
                                console.log("No transactions yet.");
                                } else {
                                    history.forEach((record, index) => {
                                        console.log(`${index + 1}. ${record}`);
                            });
                        }
                            showMenu();
                            break;

                            case '5':
                                console.log("👋Thank you for using the ATM!");
                                r1.close();
                                break;

                                default:
                                    console.log("Invalid option. try again");
                                    showMenu();
        }
    });
}
checkPIN();